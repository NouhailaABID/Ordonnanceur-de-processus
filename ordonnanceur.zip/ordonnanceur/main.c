#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dirent.h>
#include "processus.h"

// Fonction pour parser une ligne de configuration
int parser_ligne(char* ligne, Processus* p) {
    char* token = strtok(ligne, ",");
    if (!token) return 0;
    
    // Supprimer les espaces
    while (*token == ' ') token++;
    strcpy(p->nom, token);
    
    // Arrivée
    token = strtok(NULL, ",");
    if (!token) return 0;
    p->arrivee = atoi(token);
    
    // Compter d'abord le nombre de cycles
    int capa = 10;
    p->cycles = malloc(capa * sizeof(Cycle));
    p->nb_cycles = 0;
    
    while ((token = strtok(NULL, ",")) != NULL) {
        while (*token == ' ') token++;
        
        Cycle c;
        if (strncmp(token, "CPU=", 4) == 0) {
            c.type = 0;
            c.duree = atoi(token + 4);
        } else if (strncmp(token, "IO=", 3) == 0) {
            c.type = 1;
            c.duree = atoi(token + 3);
        } else {
            continue;
        }
        
        if (p->nb_cycles >= capa) {
            capa *= 2;
            p->cycles = realloc(p->cycles, capa * sizeof(Cycle));
        }
        p->cycles[p->nb_cycles++] = c;
    }
    
    return 1;
}

Processus* lire_config(char* fichier, int* nb_processus) {
    FILE* f = fopen(fichier, "r");
    if (!f) {
        printf("Erreur: impossible d'ouvrir %s\n", fichier);
        return NULL;
    }
    
    Processus* liste = malloc(100 * sizeof(Processus));
    *nb_processus = 0;
    
    char ligne[512];
    while (fgets(ligne, sizeof(ligne), f)) {
        // Ignorer commentaires et lignes vides
        if (ligne[0] == '#' || ligne[0] == '\n' || ligne[0] == '\r') continue;
        
        // Supprimer le saut de ligne
        ligne[strcspn(ligne, "\n")] = 0;
        
        Processus p;
        if (parser_ligne(ligne, &p)) {
            p.cycle_courant = 0;
            p.temps_restant = (p.nb_cycles > 0) ? p.cycles[0].duree : 0;
            p.debut = -1;
            p.fin = -1;
            p.dernier_exec = -1;
            liste[*nb_processus] = p;
            (*nb_processus)++;
        }
    }
    
    fclose(f);
    return liste;
}

void liberer_processus(Processus* processus, int nb) {
    for (int i = 0; i < nb; i++) {
        free(processus[i].cycles);
    }
    free(processus);
}

int tous_termines(Processus* processus, int nb) {
    for (int i = 0; i < nb; i++) {
        if (processus[i].cycle_courant < processus[i].nb_cycles) {
            return 0;
        }
    }
    return 1;
}

void executer_cycle_courant(Processus* p, int duree_exec, int temps_courant) {
    if (p->debut == -1 && p->cycles[p->cycle_courant].type == 0) {
        p->debut = temps_courant;  // premier démarrage CPU
    }
    
    p->temps_restant -= duree_exec;
    
    if (p->temps_restant == 0) {
        // Cycle terminé
        p->cycle_courant++;
        if (p->cycle_courant < p->nb_cycles) {
            p->temps_restant = p->cycles[p->cycle_courant].duree;
        } else {
            p->fin = temps_courant + duree_exec;
        }
    }
}

void afficher_gantt(Processus* processus, int nb, int temps_total) {
    printf("\n--- DIAGRAMME DE GANTT (simplifie) ---\n");
    printf("(CPU: #, IO: .)\n\n");
    
    for (int i = 0; i < nb; i++) {
        printf("%-8s |", processus[i].nom);
        
        // Reconstruire l'exécution (simplifié: affiche juste quand CPU actif)
        int t = 0;
        int idx_cycle = 0;
        int reste = (processus[i].nb_cycles > 0) ? processus[i].cycles[0].duree : 0;
        
        for (t = 0; t < temps_total; t++) {
            if (idx_cycle >= processus[i].nb_cycles) {
                printf("  ");
                continue;
            }
            
            if (processus[i].cycles[idx_cycle].type == 0) {
                // CPU
                if (processus[i].debut != -1 && t >= processus[i].debut && reste > 0) {
                    printf("##");
                    reste--;
                    if (reste == 0) {
                        idx_cycle++;
                        if (idx_cycle < processus[i].nb_cycles) {
                            reste = processus[i].cycles[idx_cycle].duree;
                        }
                    }
                } else {
                    printf("  ");
                }
            } else {
                // IO - on affiche juste des points
                if (reste > 0) {
                    printf("..");
                    reste--;
                    if (reste == 0) {
                        idx_cycle++;
                        if (idx_cycle < processus[i].nb_cycles) {
                            reste = processus[i].cycles[idx_cycle].duree;
                        }
                    }
                } else {
                    printf("  ");
                }
            }
        }
        printf("|\n");
    }
    
    printf("         ");
    for (int t = 0; t < temps_total; t += 5) printf("%-2d ", t);
    printf("\n");
}

void afficher_resultats(Processus* processus, int nb) {
    printf("\n========================================\n");
    printf("RESULTATS DE L'ORDONNANCEMENT\n");
    printf("========================================\n");
    
    float total_attente = 0, total_retour = 0;
    for (int i = 0; i < nb; i++) {
        int retour = processus[i].fin - processus[i].arrivee;
        
        // Calcul du temps d'attente (simplifié: fin - arrivee - somme des CPU)
        int somme_cpu = 0;
        for (int j = 0; j < processus[i].nb_cycles; j++) {
            if (processus[i].cycles[j].type == 0) {
                somme_cpu += processus[i].cycles[j].duree;
            }
        }
        int attente = retour - somme_cpu;
        
        total_attente += attente;
        total_retour += retour;
        
        printf("Processus %-6s | arrivee=%d | retour=%d | attente=%d\n",
               processus[i].nom, processus[i].arrivee, retour, attente);
    }
    printf("========================================\n");
    printf("Temps d'attente moyen : %.2f\n", total_attente / nb);
    printf("Temps de retour moyen : %.2f\n", total_retour / nb);
}

int construire_menu_dynamique(char politiques[][50]) {
    DIR* dir = opendir("politiques");
    if (!dir) {
        // Dossier par défaut
        strcpy(politiques[0], "fifo");
        strcpy(politiques[1], "sjf");
        strcpy(politiques[2], "round_robin");
        return 3;
    }
    
    int nb = 0;
    struct dirent* entree;
    while ((entree = readdir(dir)) != NULL) {
        char* ext = strrchr(entree->d_name, '.');
        if (ext && strcmp(ext, ".c") == 0) {
            int len = ext - entree->d_name;
            strncpy(politiques[nb], entree->d_name, len);
            politiques[nb][len] = '\0';
            nb++;
            if (nb >= 10) break;
        }
    }
    closedir(dir);
    return nb;
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Usage: %s <fichier_config>\n", argv[0]);
        return 1;
    }
    
    int nb_processus = 0;
    Processus* processus = lire_config(argv[1], &nb_processus);
    if (processus == NULL || nb_processus == 0) {
        printf("Erreur: Aucun processus charge\n");
        return 1;
    }
    printf("Fichier '%s' charge : %d processus\n", argv[1], nb_processus);
    
    char politiques[10][50];
    int nb_pol = construire_menu_dynamique(politiques);
    
    printf("\n========================================\n");
    printf("  POLITIQUES D'ORDONNANCEMENT\n");
    printf("========================================\n");
    for (int i = 0; i < nb_pol; i++)
        printf("  %d. %s\n", i + 1, politiques[i]);
    printf("  (defaut = FIFO si choix invalide)\n");
    printf("========================================\n");
    printf("Votre choix: ");
    
    int choix;
    if (scanf("%d", &choix) != 1) choix = 1;
    
    // Copie des processus
    Processus* copie = malloc(nb_processus * sizeof(Processus));
    for (int i = 0; i < nb_processus; i++) {
        copie[i] = processus[i];
        copie[i].cycles = malloc(processus[i].nb_cycles * sizeof(Cycle));
        memcpy(copie[i].cycles, processus[i].cycles, processus[i].nb_cycles * sizeof(Cycle));
    }
    
    int quantum = 2;
    int valide = (choix >= 1 && choix <= nb_pol);
    char* nom_pol = valide ? politiques[choix - 1] : "fifo";
    
    printf("\n--- EXECUTION : %s ---\n", nom_pol);
    
    if (strcmp(nom_pol, "fifo") == 0 || !valide) {
        fifo(copie, nb_processus);
    } else if (strcmp(nom_pol, "sjf") == 0) {
        sjf(copie, nb_processus);
    } else if (strcmp(nom_pol, "round_robin") == 0) {
        printf("Quantum [defaut=2]: ");
        int q;
        if (scanf("%d", &q) == 1 && q > 0) quantum = q;
        round_robin(copie, nb_processus, quantum);
    } else {
        printf("Politique inconnue, utilisation de FIFO.\n");
        fifo(copie, nb_processus);
    }
    
    // Calcul du temps total
    int temps_total = 0;
    for (int i = 0; i < nb_processus; i++) {
        if (copie[i].fin > temps_total) temps_total = copie[i].fin;
    }
    
    afficher_gantt(copie, nb_processus, temps_total);
    afficher_resultats(copie, nb_processus);
    
    for (int i = 0; i < nb_processus; i++) {
        free(copie[i].cycles);
    }
    free(copie);
    liberer_processus(processus, nb_processus);
    
    return 0;
}