#include <stdio.h>
#include <stdlib.h>
#include "../processus.h"

void round_robin(Processus* processus, int nb, int quantum) {
    // Trier par arrivee pour commencer
    for (int i = 0; i < nb - 1; i++) {
        for (int j = 0; j < nb - i - 1; j++) {
            if (processus[j].arrivee > processus[j+1].arrivee) {
                Processus tmp = processus[j];
                processus[j] = processus[j+1];
                processus[j+1] = tmp;
            }
        }
    }
    
    int temps = 0;
    int termine = 0;
    int* reste_global = malloc(nb * sizeof(int));
    
    for (int i = 0; i < nb; i++) {
        reste_global[i] = 0;
        for (int j = 0; j < processus[i].nb_cycles; j++) {
            reste_global[i] += processus[i].cycles[j].duree;
        }
    }
    
    int* debut_set = calloc(nb, sizeof(int));
    
    while (termine < nb) {
        int progres = 0;
        
        for (int i = 0; i < nb; i++) {
            if (reste_global[i] > 0 && processus[i].arrivee <= temps) {
                if (!debut_set[i]) {
                    processus[i].debut = temps;
                    debut_set[i] = 1;
                }
                
                int exec = (reste_global[i] < quantum) ? reste_global[i] : quantum;
                reste_global[i] -= exec;
                temps += exec;
                progres = 1;
                
                if (reste_global[i] == 0) {
                    processus[i].fin = temps;
                    termine++;
                }
            }
        }
        
        if (!progres) temps++;
    }
    
    free(reste_global);
    free(debut_set);
}