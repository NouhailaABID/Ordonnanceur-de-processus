#include <stdio.h>
#include "../processus.h"

void fifo(Processus* processus, int nb) {
    // Trier par date d'arrivée
    for (int i = 0; i < nb - 1; i++) {
        for (int j = 0; j < nb - i - 1; j++) {
            if (processus[j].arrivee > processus[j+1].arrivee) {
                Processus tmp = processus[j];
                processus[j] = processus[j+1];
                processus[j+1] = tmp;
            }
        }
    }
    
    int temps = 0;
    for (int i = 0; i < nb; i++) {
        if (temps < processus[i].arrivee)
            temps = processus[i].arrivee;
        
        // Exécuter tous les cycles du processus
        processus[i].debut = temps;
        int duree_totale = 0;
        for (int j = 0; j < processus[i].nb_cycles; j++) {
            duree_totale += processus[i].cycles[j].duree;
        }
        temps += duree_totale;
        processus[i].fin = temps;
    }
}