#include <stdio.h>
#include <stdlib.h>
#include "../processus.h"

// Calculer la durée totale CPU d'un processus
int duree_totale_cpu(Processus* p) {
    int total = 0;
    for (int i = 0; i < p->nb_cycles; i++) {
        if (p->cycles[i].type == 0) {
            total += p->cycles[i].duree;
        }
    }
    return total;
}

void sjf(Processus* processus, int nb) {
    int temps = 0;
    int termine = 0;
    int* execute = calloc(nb, sizeof(int));
    Processus* temp = malloc(nb * sizeof(Processus));
    
    for (int i = 0; i < nb; i++) temp[i] = processus[i];
    
    while (termine < nb) {
        int idx = -1;
        int min_cpu = 999999;
        
        for (int i = 0; i < nb; i++) {
            if (!execute[i] && temp[i].arrivee <= temps) {
                int cpu = duree_totale_cpu(&temp[i]);
                if (cpu < min_cpu) {
                    min_cpu = cpu;
                    idx = i;
                }
            }
        }
        
        if (idx != -1) {
            temp[idx].debut = temps;
            int duree_totale = 0;
            for (int j = 0; j < temp[idx].nb_cycles; j++) {
                duree_totale += temp[idx].cycles[j].duree;
            }
            temps += duree_totale;
            temp[idx].fin = temps;
            execute[idx] = 1;
            termine++;
        } else {
            temps++;
        }
    }
    
    for (int i = 0; i < nb; i++) {
        processus[i].debut = temp[i].debut;
        processus[i].fin = temp[i].fin;
    }
    
    free(execute);
    free(temp);
}