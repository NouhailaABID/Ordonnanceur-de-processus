#ifndef PROCESSUS_H
#define PROCESSUS_H

typedef struct {
    int type;      // 0 = CPU, 1 = IO
    int duree;     // durée en ms
} Cycle;

typedef struct {
    char nom[50];
    int arrivee;           // date d'arrivée
    Cycle* cycles;         // tableau des cycles
    int nb_cycles;         // nombre total de cycles
    int cycle_courant;     // cycle en cours d'exécution
    int temps_restant;     // temps restant dans le cycle actuel
    int debut;             // début du processus (premier CPU)
    int fin;               // fin du dernier cycle
    int dernier_exec;      // dernière fois qu'il a été exécuté (pour RR)
} Processus;

// Prototypes des politiques
void fifo(Processus* processus, int nb);
void sjf(Processus* processus, int nb);
void round_robin(Processus* processus, int nb, int quantum);

#endif